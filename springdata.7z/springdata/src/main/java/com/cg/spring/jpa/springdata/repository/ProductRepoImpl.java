package com.cg.spring.jpa.springdata.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.jpa.springdata.bean.Product;

@Component
public class ProductRepoImpl implements IProductRepo {
	
	List <Product> list;
	
	@Autowired
	EntityManager em;
	
	@Override
	public List<Product> getAllProducts() {
		Query q = em.createQuery("from Product");
		list = q.getResultList();
		return list;
	}

	@Override
	@Transactional
	public void add(int id, String name, double price) {
		Product p = new Product();
		p.setId(id);
		p.setName(name);
		p.setPrice(price);
		em.persist(p);
		
	}

	@Override
	public void update(String name, double price) {		
		
	}

	
	
	
}

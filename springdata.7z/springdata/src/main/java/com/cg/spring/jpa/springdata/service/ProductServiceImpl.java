package com.cg.spring.jpa.springdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.springdata.bean.Product;
import com.cg.spring.jpa.springdata.repository.IProductRepo;

@Component
public class ProductServiceImpl implements IProductService{

	
	@Autowired
	IProductRepo repo;

	@Override
	public List<Product> getAllProducts() {
		return repo.getAllProducts();
	}

	@Override
	public void add(int id, String name, double price) {
		repo.add(id,name,price);
		
	}
}
